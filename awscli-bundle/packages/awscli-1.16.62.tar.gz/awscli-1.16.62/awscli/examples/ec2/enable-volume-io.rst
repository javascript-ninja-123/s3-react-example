**To enable I/O for a volume**

This example enables I/O on volume ``vol-1234567890abcdef0``.

Command::

  aws ec2 enable-volume-io --volume-id vol-1234567890abcdef0
  
Output::

  {
    "Return": true
  }